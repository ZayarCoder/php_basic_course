<?php 
echo "Study" . $_GET['subject'] . "at" . $_GET['web'];